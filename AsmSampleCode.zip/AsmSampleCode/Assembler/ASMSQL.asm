         TITLE 'ASMSQL'                                                         
         PRINT NOGEN                                                            
ASMSQL   CSECT                                                                  
*                                                                               
ASMSQL   AMODE 31                                                               
ASMSQL   RMODE 24                                                               
*                                                                               
MAIN_RTN EQU     *                                                              
         USING   ASMSQL,R5                                                      
         L       R5,0(R1)                                                       
*                                                                               
         LA      R10,MY_SQLDWK                                                  
         USING   SQLDSECT,R10                                                   
*                                                                               
         L       R7,CN_KEYAREA_SIZE                                             
         GETMAIN R,LV=(R7)                                                      
         ST      R1,MY_KEY_ADR                                                  
*                                                                               
LABEL1  DS  0H                                                                  
*                                                                               
        EXEC SQL DECLARE TB000001 TABLE                                X        
                (TB1_ID             CHAR(8)      NOT NULL,             X        
                 TB1_FIELD001         INTEGER,                         X        
                 TB1_FIELD002         INTEGER)                                  
*                                                                               
        MVC    MY_TAB1_FIELD2,CN_VSVAL                                          
*                                                                               
        EXEC   SQL                                                     X        
               SELECT TB1_ID                                           X        
                 INTO :MY_TAB1_ID                                      X        
                 FROM TB000001                                         X        
                WHERE TB1_FIELD002 = :MY_TAB1_FIELD2                            
*                                                                               
        IF (CLC,SQLSTATE,EQ,CN_SQLEOF)                                          
        ELSE                                                                    
           IF (CLC,SQLSTATE,NE,CN_SQLNRML)                                      
                MVC    MY_OPID,CN_SELECT                                        
                B      LABEL2                                                   
           ELSE                                                                 
                MVI    MY_WAIT_FLG,CN_EQU_1                                     
           ENDIF                                                                
        ENDIF                                                                   
*                                                                               
LABEL2  DS  0H                                                                  
*                                                                               
        L      R11,MY_IDINF_ADR                                                 
*                                                                               
        IF (CR,R7,NE,R11)                                                       
*                                                                               
           DO  INF                                                              
*                                                                               
           DOEXIT (CR,R7,LT,R11)                                                
*                                                                               
           DOEXIT (CP,MY_IDCNT,LT,MY_PRC_CNT)                                   
             IF  (CLC,0(4,R7),EQ,0(R11)),AND,                          X        
               (CR,R7,NE,R11)                                                   
                LA   R7,16(R7)                                                  
             ELSE                                                               
                LA   R11,16(R11)                                                
             ENDIF                                                              
           ENDDO                                                                
        ELSE                                                                    
        ENDIF                                                                   
*                                                                               
        EXEC  SQL  DECLARE  TB000002  TABLE                            X        
                  (TB2_ID              CHAR(4)   NOT NULL,             X        
                   TB2_FIELD001             CHAR(3)   ,                X        
                   TB2_FIELD002             CHAR(3)                             
*                                                                               
        MVC     MY_TAB2_FIELD2,CN_ACT                                           
        MVC     MY_TAB2_ID,0(R7)                                                
        EXEC     SQL                                                   X        
                 OPEN  CUR001                                                   
*                                                                               
        IF (CLC,SQLSTATE,NE,CN_SQLNRML)                                         
           MVC    MY_OPID,CN_OPEN                                               
        ELSE                                                                    
        ENDIF                                                                   
*                                                                               
        EXEC    SQL                                                    X        
                FETCH  CUR001                                          X        
                 INTO  :MY_TAB2_ID,                                    X        
                       :MY_TAB2_FIELD1                                          
        SELECT                                                                  
          WHEN  (CLC,SQLSTATE,EQ,CN_SQLEOF)                                     
             MVI     MY_EOF_FLG,CN_ON                                           
*                                                                               
          WHEN  (CLC,SQLSTATE,EQ,CN_SQLNRML)                                    
             MVC  0(4,R8),MY_TAB2_ID                                            
*                                                                               
          OTHER                                                                 
             MVC  MY_OPID,CN_FETCH                                              
*                                                                               
        ENDSEL                                                                  
*                                                                               
        EXEC    SQL                                                    X        
                CLOSE  CUR001                                                   
*                                                                               
        IF (CLC,SQLSTATE,NE,CN_SQLNRML)                                         
           MVC    MY_OPID,CN_CLOSE                                              
        ELSE                                                                    
        ENDIF                                                                   
         EJECT                                                                  
*                                                                               
        MVC    MY_TAB1_FIELD1,MY_RUN_FLG                                        
*                                                                               
        EXEC   SQL                                                     X        
               UPDATE TB000001                                         X        
                  SET TB1_FIELD001       = :MY_TAB1_FIELD1             X        
                WHERE TB1_ID      = :MY_TAB1_ID                                 
*                                                                               
        IF (CLC,SQLSTATE,NE,CN_SQLNRML)                                         
           MVC    MY_OPID,CN_UPDATE                                             
        ELSE                                                                    
        ENDIF                                                                   
*                                                                               
         LTORG                                                                  
*                                                                               
SQLDSECT        DSECT                                                           
         EXEC   SQL  INCLUDE  SQLCA                                             
*                                                                               
                DS    0F                                                        
MY_SQLDWK       DS    (SQLDLEN)C                                                
*                                                                               
MY_TAB1_ID      DS    CL8                                                       
MY_TAB1_FIELD1  DS    CL26                                                      
MY_TAB1_FIELD2  DS    CL26                                                      
MY_TAB2_ID      DS    CL4                                                       
MY_TAB2_FIELD1  DS    CL3                                                       
MY_TAB2_FIELD2  DS    CL3                                                       
                DS    0F                                                        
*                                                                               
         EXEC   SQL                                                    X        
                DECLARE  CUR001  CURSOR  FOR                           X        
                 SELECT  TB2_ID,                                       X        
                         TB2_FIELD001                                  X        
                   FROM  TB000002                                      X        
                  WHERE  TB2_FIELD002 = :MY_TAB2_FIELD2                         
*                                                                               
CN_ON             EQU   C'1'                                                    
CN_OFF            EQU   C'0'                                                    
*                                                                               
CN_EQU_1          EQU   1                                                       
*                                                                               
CN_KEYAREA_SIZE   DC    F'4000'                                                 
*                                                                               
CN_OPEN           DC    CL6'OPEN'                                               
CN_CLOSE          DC    CL6'CLOSE'                                              
CN_FETCH          DC    CL6'FETCH'                                              
CN_SELECT         DC    CL6'SELECT'                                             
CN_UPDATE         DC    CL6'UPDATE'                                             
CN_VSVAL          DC    CL8'VALUE001'                                           
*                                                                               
CN_SQLNRML        DC    CL5'00000'                                              
CN_SQLEOF         DC    CL5'02000'                                              
*                                                                               
CN_ACT            DC    CL3'ACT'                                                
                  DS    0F                                                      
MY_N007I_PARM     DS    0CL3232                                                 
                  SDAN007I                                                      
                  DS    CL1600                                                  
CN_N007I_LEN      EQU   *-MY_N007I_PARM                                         
*                                                                               
                  DS    0F                                                      
MY_KEY_ADR        DS    A                                                       
MY_IDINF_ADR      DS    A                                                       
*                                                                               
                  DS    0D                                                      
MY_IDCNT          DS    PL8                                                     
MY_PRC_CNT        DS    PL2                                                     
MY_RUN_FLG        DS    0F                                                      
*                                                                               
MY_WAIT_FLG       DS    CL1                                                     
*                                                                               
                  ORG                                                           
MY_OPID          DS    CL6                                                      
*                                                                               
MY_EOF_FLG        DS    CL1                                                     
*                                                                               
         COPY     RESP                                                          
*                                                                               
         END  JSANUT02                                                          
