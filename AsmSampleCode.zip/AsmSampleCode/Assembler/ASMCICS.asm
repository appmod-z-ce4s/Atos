         TITLE 'ASMCICS'                                                        
         PRINT NOGEN                                                            
ASMCICS  CSECT                                                                  
*                                                                               
ASMCICS  AMODE 31                                                               
ASMCICS  RMODE ANY                                                              
*                                                                               
MAIN_RTN EQU     *                                                              
*                                                                               
         USING   DFHEIBLK,R5                                                    
         L      R4,0(R1)                                                        
*                                                                               
         EXEC   CICS ADDRESS EIB(R5)                                            
*                                                                               
         EXEC   CICS ADDRESS CWA(R7)                                            
*                                                                               
         ST     R7,MY_CWA_ADDR                                                  
*                                                                               
         XC      MY_ECB_ADDR,MY_ECB_ADDR                                        
         LA      R1,MY_ECB_ADDR                                                 
*                                                                               
         ST      R4,MY_PARM_ADDR                                                
         LA      R1,4                                                           
         STH     R1,MY_PARM_LEN                                                 
*                                                                               
         EXEC    CICS  START  TRANSID('AN01')                          X        
                              FROM(MY_PARM_ADDR)                       X        
                              LENGTH(MY_PARM_LEN)                      X        
                              RESP(MY_RESP)                            X        
                              RESP2(MY_RESP2)                                   
*                                                                               
         IF (CLC,MY_RESP,NE,DFHRESP(NORMAL))                                    
            B   END_RTN                                                         
         ENDIF                                                                  
*                                                                               
         LA     R7,MY_ECB_ADDR                                                  
*                                                                               
         EXEC   CICS  WAIT  EVENT                                      X        
                            ECADDR(R7)                                 X        
                            RESP(MY_RESP)                              X        
                            RESP2(MY_RESP2)                                     
*                                                                               
         IF (CLC,MY_RESP,NE,DFHRESP(NORMAL))                                    
            B   END_RTN                                                         
         ENDIF                                                                  
*                                                                               
END_RTN  DS     0H                                                              
*                                                                               
         L      R13,MY_RESP                                                     
         L      R12,MY_RESP2                                                    
         BR     R14                                                             
*                                                                               
                  DS    0F                                                      
MY_PARM_LEN       DS    H                                                       
*                                                                               
                  DS   0F                                                       
MY_ECB_ADDR       DS   A                                                        
MY_PARM_ADDR      DS   A                                                        
MY_CWA_ADDR       DS   A                                                        
*                                                                               
         COPY     RESP                                                          
*                                                                               
         END                                                                    
