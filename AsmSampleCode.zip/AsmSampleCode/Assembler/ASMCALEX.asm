
         TITLE 'ASMCALEX- DYNAMIC CALL EXAMPLE USING MACRO'
ASMCALEX CEEENTRY PPA=XMPPPA,BASE=(R3,R4),AUTO=WORKSIZE,RMODE=24       

         USING WORKAREA,R13                                            
         B     ASSMRUN
         LTORG   ,                                                     

*
S1       MDSECT  DSECT=NO
S2       MDSECT  DSECT=NO
S3       MDSECT  DSECT=NO
ASSMRUN  DS    0H
*
         CALLEX  COBCALEX,(S1_VAR,S2_VAR,S3_VAR,WORKCC)  EXT CALL

         CLI   WORKCC,X'FF'          CHECK RETURN CODE
         BE    EOJOB                 N, STOP RUN
         SR    R9,R9                 ZERO RETURN CODE
EOJOB    DS    0H
         LR    R15,R9                LOAD RETURN CODE INTO R15

         BR    R14
*
         LTORG
         EJECT
         PRINT GEN
*        PRINT NOGEN
         EJECT
*
* ------------------------------------------------------------------- *
*  DSECTS AND EQUATES                                                 *
* ------------------------------------------------------------------- *
*
         RNEQU                                                         
*
WORKAREA DSECT                                                         
WORKCC   DC    CL2' '

WORKSIZE EQU   *-WORKAREA                                              
*
         END   ASMCALEX 
